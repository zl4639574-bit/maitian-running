# -*- coding: utf-8 -*-
"""
麦田守望 · 待审台安装器
================================================================
把「收件箱」升级成「待审台」：逐条看明细 + 与线上现状对比 + 通过即上线。

■ 它改了什么（就两处，都极小）
   1) 新增一个文件      assets/inbox-review.js          ← 审核台本体（独立文件）
   2) 改 captain/index.html 里的 boot()：app.js 加载完之后，多加载一行 inbox-review.js
   ★ assets/app.js 一个字都不动 —— 所以数据写入逻辑跟原来完全一样，不可能写坏数据。

■ 用法（在本文件所在目录执行）
   python _装待审台.py            # 安装
   python _装待审台.py --rename   # 安装，并把卡片标题从「① 收件箱」改成「待审台」
   python _装待审台.py --回滚      # 撤销：删掉 inbox-review.js，恢复 index.html

■ 安装完记得提交并推送（用你平时的方式：更新并上传.bat / git）
================================================================
"""
import io
import os
import re
import shutil
import sys
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))

# 定位仓库根目录：优先「本目录的上一级」，其次「本目录」
CAND = [os.path.abspath(os.path.join(HERE, '..')), HERE]


def find_repo():
    for d in CAND:
        if os.path.isfile(os.path.join(d, 'assets', 'app.js')) and \
           os.path.isfile(os.path.join(d, 'captain', 'index.html')):
            return d
    return None


OLD_BOOT = """  function boot() {
    var a = document.createElement('script');
    a.src = R + 'assets/app.js?t=' + Date.now();
    document.head.appendChild(a);
  }"""

NEW_BOOT = """  function boot() {
    var a = document.createElement('script');
    a.src = R + 'assets/app.js?t=' + Date.now();
    a.onload = function () {
      // 待审台：app.js 就绪后再挂上审核层（独立文件，不修改 app.js）
      if (window.__mtInboxReview) return;
      var x = document.createElement('script');
      x.src = R + 'assets/inbox-review.js?t=' + Date.now();
      document.head.appendChild(x);
    };
    document.head.appendChild(a);
  }"""

OLD_H2 = '收件箱（队员直接提交的）'
NEW_H2 = '待审台（队员直接提交的，点「通过并上线」立刻推上网站）'

OLD_TIP = ('队员在收集页点「⚡ 直接提交给队长」的内容都在这儿（存在仓库 data/inbox/）。\n'
           '      <b>接收</b>后就写进你的本机，再去「数据管理 → 比赛成绩 / 队员名册」同步上线；<b>丢弃</b>会把这条从收件箱删掉。')
NEW_TIP = ('队员在收集页点「⚡ 直接提交给队长」的内容都在这儿排队（存在仓库 data/inbox/），<b>还没上线</b>。\n'
           '      逐条看清「和现在有什么不同」再决定：<b>通过并上线</b>＝写进数据并立刻推上网站；<b>驳回</b>＝删掉队列里的这条并记下理由。')


def stamp():
    return datetime.now().strftime('%Y%m%d-%H%M%S')


def read(p):
    # newline='' 很关键：保留原来的换行符（CRLF/LF），否则整个文件会被重写、git diff 显示全变了
    with io.open(p, encoding='utf-8', newline='') as f:
        return f.read()


def write(p, t):
    with io.open(p, 'w', encoding='utf-8', newline='') as f:
        f.write(t)


def backup(path):
    """备份文件用 _*.tmp 命名 —— 正好命中仓库 .gitignore 里的 _*.tmp，不会误提交"""
    d, n = os.path.split(path)
    b = os.path.join(d, '_备份_' + n + '_' + stamp() + '.tmp')
    shutil.copyfile(path, b)
    return b


def nlof(t):
    """这个文件用的是 CRLF 还是 LF。必须照原样保留 —— 否则整个文件会被重写、
       git diff 会显示『每一行都改了』，那是最招人恨的一种补丁。"""
    return '\r\n' if '\r\n' in t else '\n'


def adapt(s, nl):
    return s.replace('\n', nl)


def main():
    rename = '--rename' in sys.argv
    rollback = ('--回滚' in sys.argv) or ('--rollback' in sys.argv)

    repo = find_repo()
    if not repo:
        print('❌ 没找到仓库根目录（需要有 assets/app.js 和 captain/index.html）')
        print('   把本文件放在仓库根目录下再跑一次，或放在根目录的上一级。')
        return 1

    src_js = os.path.join(HERE, 'assets', 'inbox-review.js')
    dst_js = os.path.join(repo, 'assets', 'inbox-review.js')
    src_check = os.path.join(HERE, '_自检_待审台.html')
    dst_check = os.path.join(repo, '_自检_待审台.html')
    idx = os.path.join(repo, 'captain', 'index.html')
    app = os.path.join(repo, 'assets', 'app.js')
    print('仓库根目录：' + repo)

    # ---------------- 回滚 ----------------
    if rollback:
        if os.path.isfile(dst_js):
            os.remove(dst_js)
            print('✅ 已删除 assets/inbox-review.js')
        if os.path.isfile(dst_check):
            os.remove(dst_check)
            print('✅ 已删除 _自检_待审台.html')
        t = read(idx)
        nl = nlof(t)
        if adapt(NEW_BOOT, nl) in t:
            write(idx, t.replace(adapt(NEW_BOOT, nl), adapt(OLD_BOOT, nl)))
            print('✅ captain/index.html 已恢复原样')
        else:
            print('· captain/index.html 本来就没打过补丁，跳过')
        print('回滚完成。记得提交并推送一次。')
        return 0

    # ---------------- 检查 ----------------
    if not os.path.isfile(src_js):
        print('❌ 找不到 assets/inbox-review.js（它应该和本文件在同级 assets/ 目录里）')
        print('   应位于：' + src_js)
        return 1

    t = read(idx)
    nl = nlof(t)                                   # 照原文件的换行符来匹配与替换
    old_boot, new_boot = adapt(OLD_BOOT, nl), adapt(NEW_BOOT, nl)
    already = 'assets/inbox-review.js' in t and new_boot in t
    if already:
        print('· captain/index.html 之前已经打过补丁，这次只更新 inbox-review.js 本体')
    elif old_boot not in t:
        print('❌ captain/index.html 里的 boot() 与预期不一致（可能被改过）—— 不敢乱动，已中止。')
        print('   请手动在 assets/app.js 加载之后补一行：')
        print("     a.onload = function () { var x = document.createElement('script');")
        print("       x.src = R + 'assets/inbox-review.js?t=' + Date.now(); document.head.appendChild(x); };")
        return 1

    # ---------------- 1) 放文件 ----------------
    shutil.copyfile(src_js, dst_js)
    print('✅ 已写入 assets/inbox-review.js（%d 字节）' % os.path.getsize(dst_js))
    if os.path.isfile(src_check):
        shutil.copyfile(src_check, dst_check)
        print('✅ 已写入 _自检_待审台.html（自检页，可随时打开验证，不影响线上）')

    # ---------------- 2) 改 index.html ----------------
    if not already:
        bak = backup(idx)
        write(idx, t.replace(old_boot, new_boot, 1))
        print('✅ 已修改 captain/index.html（备份：%s）' % os.path.basename(bak))
        t2 = read(idx)
        assert 'assets/inbox-review.js' in t2, '补丁没写进去'
        assert (t2.count('\n') - t2.count('\r\n')) == (t.count('\n') - t.count('\r\n')), '换行符混用了'
        print('   校验：已出现 inbox-review.js ✅；换行符与原文件同一种 ✅（只动了 boot() 那几行）')
    else:
        print('· index.html 无需改动')

    # ---------------- 3) 可选：改标题文案 ----------------
    if rename:
        a = read(app)
        an = nlof(a)
        n = 0
        for o, w in ((OLD_H2, NEW_H2), (OLD_TIP, NEW_TIP)):
            o2, w2 = adapt(o, an), adapt(w, an)
            if o2 in a:
                a = a.replace(o2, w2, 1); n += 1
        if n:
            bak = backup(app)
            write(app, a)
            a2 = read(app)
            assert (a2.count('\n') - a2.count('\r\n')) == (a.count('\n') - a.count('\r\n')), '换行符混用了'
            print('✅ 已改卡片标题与说明文案（%d 处，备份：%s，换行符未变 ✅）' % (n, os.path.basename(bak)))
        else:
            print('· 文案已经是新的（或没找到原文），跳过')

    print('')
    print('== 安装完成，接下来 ==')
    print('  1) 提交并推送（用你平时的方式），等 GitHub Pages 生效 30–90 秒')
    print('  2) 打开队长版 → 顶部「上传成绩」→ 第一张卡就是待审台')
    print('  3) 点一次「读取待审队列」；想确认装好了，可以本地打开 _自检_待审台.html（25 项全绿就对了），')
    print('     或在队长版控制台跑：__mtInboxReview.selfCheck()   → ok:true')
    print('  ⚠️ 队员侧要能「⚡ 直接提交」，得先在「数据管理 → 同步 → 收件中转」配好收件服务')
    print('     （否则队员只能走「📤 发给队长（微信）」，待审台永远是空的）')
    return 0


if __name__ == '__main__':
    sys.exit(main())
